package treeGUI;

import java.io.IOException;

import address.Address;
import address.AddressCoords;
import address.Coordinate;
import address.CoordinatesNearby;
import address.FindShortestPath;
import address.OptimizeCoordinates;
import dataSensitiviTree.Client;
import dataSensitiviTree.UserValues;
//import dataSensitiviTree.TreeParser;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import pollenCalculation.AllergyRating;

public class SensitiviTreeGUI extends Application{
	
	private static final String datafolder = "data";
	
	public static void main(String args[]) throws IOException{
		Client.generate();
		launch(args);
	}

	@Override
	public void start(Stage primarystage) throws Exception {
		
		// The image file to use for background
		Image image = new Image("sensitiviTree.png");
		
		ImageView iv2 = new ImageView();
        iv2.setImage(image);
        iv2.setFitWidth(400);
        iv2.setPreserveRatio(true);
        iv2.setSmooth(true);
        iv2.setCache(true);
        
		VBox verticalLayout1 = new VBox(5);
		verticalLayout1.setPadding(new Insets(15, 12, 15, 12));
		verticalLayout1.setStyle("-fx-background-color: #809970;");
		
		Label labelInput = new Label("Enter An Address Within Ottawa");
		Label labelTo = new Label("Enter an address to find a path to");
		Text species = new Text();
		species.setFont(Font.font ("Calibri", 16));
		
		Text highPollenSpecies = new Text();
		highPollenSpecies.setFont(Font.font ("Calibri", 20));
		highPollenSpecies.setFill(Color.RED);
		
		
		Label addressLabel = new Label("");
		addressLabel.setFont(new Font("Arial", 30));
		Text t = new Text();
		t.setText("");
		t.setFont(Font.font ("Verdana", 20));
		t.setFill(Color.GREEN);
		
		Text t2 = new Text();
		t2.setText("Prints path to console");
		t2.setFont(Font.font ("Calibri", 12));
		t2.setFill(Color.BLACK);
		
		
		TextField textField = new TextField();
		textField.setMaxWidth(300);
		
		TextField toAddress = new TextField();
		toAddress.setMaxWidth(300);
		
		Button submit = new Button("Pollen Rating");
		Button submit2 = new Button("Find Low Pollen Path");
		
		verticalLayout1.getChildren().addAll(labelInput, textField, submit,labelTo,toAddress,submit2,t2, addressLabel,t,highPollenSpecies, species, iv2);
		
	    Scene scene=new Scene(verticalLayout1, 600, 500);
	    primarystage.setTitle("SensitiviTree");
        primarystage.setScene(scene);
	    primarystage.show();
	    
	    submit.setOnAction(new EventHandler<ActionEvent>() {

	    	@Override
	    	    public void handle(ActionEvent e) {
	    	        if ((textField.getText() != null && !textField.getText().isEmpty())) {
	    	        	UserValues.setUserLocation(textField.getText().toUpperCase());
	    	        	double pollenRating = Client.getRating();
	    	        	addressLabel.setText("Allergen Rating: " + pollenRating);
	    	        	if (pollenRating >= 300) {
	    	        		t.setText("EXTREME POLLEN"); t.setFill(Color.DARKRED);
	    	        	}
	    	        	else if (pollenRating >= 200) {
	    	        		t.setText("SEVERE POLLEN"); t.setFill(Color.RED);
	    	        	}
	    	        	else if (pollenRating > 100) {
	    	        		t.setText("HIGH POLLEN"); t.setFill(Color.ORANGE);
	    	        	}
	    	        	else if (pollenRating > 50) {
	    	        		t.setText("MODERATE POLLEN"); t.setFill(Color.YELLOW);
	    	        	}
	    	        	else if (pollenRating >= 25) {
	    	        		t.setText("MILD POLLEN"); t.setFill(Color.LIGHTGREEN);
	    	        	}
	    	        	else {
	    	        		t.setText("VERY LOW POLLEN"); t.setFill(Color.GREEN);
	    	        	}
	    	        	highPollenSpecies.setText("Nearby Major Pollen Producers:");
	    	        	species.setText(Client.getNearbySpecies());
	    	        	//layout1.getChildren().add(addressLabel);
	    	        }
	    	     }
	    	 });
	    
	    submit2.setOnAction(new EventHandler<ActionEvent>() {

	    	@Override
	    	    public void handle(ActionEvent e) {
	    		UserValues.setInputStreet(textField.getText().toUpperCase());
	    		UserValues.setFindStreet(toAddress.getText().toUpperCase());
	    		System.out.println("Reading the graph and generating a path, please wait...");
	    		Address[] addresses = Client.getAddresses();
	    		Coordinate[] coordinates = null;
				try {
					coordinates = AddressCoords.buildCoords(addresses);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				String a1 = textField.getText().toUpperCase();
				String a2 = toAddress.getText().toUpperCase();
				System.out.println("Creating a graph and connecting edges...\n\n");
	    		Coordinate[] optimizedCoordinates = OptimizeCoordinates.optimizeCoordinate(coordinates);
	    		CoordinatesNearby.findNearbyCoordinate(optimizedCoordinates); 
	    		try {
	    			System.out.println((FindShortestPath.findPath(addresses, optimizedCoordinates, a1, a2)));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	    }
	    	     
	    	 });
		
	}
}