package dataSensitiviTree;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import address.Address;
import address.AddressFinder;
import address.AddressParser;
import address.Coordinate;
import address.CoordinateDigraph;
import address.CoordinateGraph;
import address.CoordinatesNearby;
import address.FindShortestPath;
import address.OptimizeCoordinates;
import algorithms.Digraph;
import algorithms.DirectedDFS;
import address.AddressCoords;
import pollenCalculation.AllergyRating;
import pollenCalculation.TreeAllergenLevel;
import tree.GenTrees;
import tree.Tree;
import tree.TreeCoordinates;
import tree.TreeCounter;

public class Client {
	
	private static Tree[] trees;
	private static Address[] addresses;
	private static Coordinate[] coordinates;
	public static void generate() throws IOException {
		
		//UserValues.setInputStreet("10 WILLOW ST");
		//UserValues.setFindStreet("421 ARLINGTON AVE");
		
		//UserValues.setInputStreet("10 WILLOW ST");
		//UserValues.setFindStreet("320 OSGOODE ST");
		
		System.out.println("Read the README in the root project folder\nfor more information!");
		System.out.println("Generating trees...");
		trees = GenTrees.generate();
		System.out.println("Generating addresses...");
		addresses = AddressParser.genAddresses();
		System.out.println("Building an address BST...");
		AddressFinder.buildAddressBST(addresses);
		TreeCoordinates.treeCoordinateFinder(trees,addresses);
		
		//CoordinateGraph.buildCoordinateGraph(coordinates);
		//System.out.println(coordinates[50000].getNearbyCoordIDs());
//		Digraph graph = CoordinateDigraph.buildDigraph(coordinates);
//		DirectedDFS dfs = new DirectedDFS(graph,75000);
//		System.out.println(dfs.count());
		//String a1 = UserValues.getInputStreet();
		//String a2 = UserValues.getFindStreet();
		//System.out.println("Creating a graph and connecting edges...");
		//FindShortestPath.findPath(addresses, optimizedCoordinates, a1, a2);
		
		//System.out.println("SAMPLE ADDRESSES: \n131 QUEEN ST\n66 ROSEDALE AVE\n867 NESTING WAY\n1414 ROSENTHAL AVE\n1682 ST. BARBARA ST\n277 PARKDALE AVE");
	}
	
	public static double getRating(){
		return AllergyRating.calculateRating(trees, 200);
	}
	
	public static Address[] getAddresses() {
		return addresses;
	}
	
	public static String getNearbySpecies() {
		int counter = 0;
		String speciesString = "";
		HashMap<String,Integer> species = TreeCounter.count(trees, 100);
		for (Entry<String, Integer> s : species.entrySet()) {
		    String key = s.getKey();
		    Object value = s.getValue();
		    int allergyLevel = TreeAllergenLevel.calculateAllergen(s.getKey());
		    if ((allergyLevel >= 5) && counter <= 3) {
		    	speciesString = speciesString + s.getKey() + ", ";
		    	counter ++;
		    }
		}
		if (speciesString.length() > 0){
			return speciesString.substring(0, speciesString.length() - 2);
		}
		else {
			return "NONE";
		}
		
	}
}
