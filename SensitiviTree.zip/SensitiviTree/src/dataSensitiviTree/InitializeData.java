package dataSensitiviTree;

import java.io.IOException;
import java.util.List;

import address.Coordinate;
import algorithms.RedBlackBST;

public class InitializeData {

	public static void main(String[] args) throws IOException {
		Client.generate();
	}
}
