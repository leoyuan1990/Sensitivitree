package dataSensitiviTree;

import address.Address;
import address.AddressFinder;
import address.Coordinate;
import algorithms.RedBlackBST;

/*
 * this class will store all the information about what the user has entered
 * note that this class does not check for valid entries
 * classes that set values using these methods must check for validity
 * specifically, the class for userInput
 */
public class UserValues {
	
	private static boolean useCurrentLocation = true;
	private static String streetName;
	private static int addressNum;
	private static double userX;
	private static double userY;
	private static RedBlackBST addressesBST;
	private static String findStreet;
	private static Address userAddress;
	
	public static void setUserLocation(String address){
		addressesBST = AddressFinder.getBST();
		userAddress = (Address) addressesBST.get(address);
		
		setInputStreet(userAddress.getAddFullName().toUpperCase());
		setX(userAddress.getPointX());
		setY(userAddress.getPointY());
		setAddressNum(userAddress.getAddNum());
	}
	
	public static void setLocationOption(boolean searchHere){
		useCurrentLocation = searchHere;
	}
	public static boolean getLocationOption(){
		return useCurrentLocation;
	}
	
	public static Address getUserAddress(){
		return userAddress;
	}
	
	public static void setUserAddress(Address address){
		userAddress = address;
	}
	
	public static void setInputStreet(String street){
		streetName = street;
	}
	public static String getInputStreet(){
		return streetName;
	}
	
	public static String getFindStreet() {
		return findStreet;
	}
	
	public static void setFindStreet(String s) {
		findStreet = s;
	}
	public static void setAddressNum(int addNum){
		addressNum = addNum;
	}
	public static int getAddresssNum(){
		return addressNum;
	}
	
	public static double getX(){
		double xc = userX;
		return xc;
	}
	
	public static double getY(){
		double yc = userY;
		return yc;
	}
	
	public static void setX(double x){
		userX = x;
	}
	
	public static void setY(double y){
		userY = y;
	}
	
}
