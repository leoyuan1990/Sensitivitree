package tree;

import java.io.IOException;

import address.Address;
import address.AddressFinder;
import algorithms.RedBlackBST;

//*:
public class TreeCoordinates {
	
	private static Address address;
	
	public static void treeCoordinateFinder(Tree [] trees, Address [] addresses) throws IOException {
		RedBlackBST addressSearch = AddressFinder.getBST();
		
		/*
		 * for every tree we have, if there is a an address point that has
		 * the same address as that tree, update that tree's X and Y variables with
		 * the coordinates from the address
		 */
		for (Tree tree : trees) {
			address = (Address) addressSearch.get(tree.getAddressFullName());
			// if that tree's address exists in the address BST then...
			if (address != null) {
				tree.setX(address.getPointX());
				tree.setY(address.getPointY());
			}
			else {
				tree.setX(-1);
				tree.setY(-1);
			}
		}	
	}

}
