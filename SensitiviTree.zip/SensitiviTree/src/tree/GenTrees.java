package tree;
import java.io.*;
import java.util.*;

import algorithms.Quick;

// delete comment later

/*
 * this class reads the tree-inventory.csv and reads the data
 * returns an array of Tree objects containing all the trees in tree-inventory.csv
 */
public class GenTrees {
	
	private static final String datafolder = "data";

	public static Tree[] generate() {
		int size = 157832;
		Tree[] all = new Tree[size];
		Scanner x;
		try {
			x = new Scanner(new File(datafolder + "/tree-inventory.csv"));
			String line = x.nextLine(); //this line reads the headers
			for(int i = 0; i < size; i++) {
				line = x.nextLine();
				String[] tree = line.split(",");
				int an = Integer.parseInt(removeNonNumerical(tree[2]));
				int as = Integer.parseInt(removeNonNumerical(tree[3]));
				String loc = tree[4];
				String spec = tree[9];
				int d = Integer.parseInt(removeNonNumerical(tree[10]));
				String str = tree[13];
				all[i] = new Tree(an, as, loc, spec, d, str);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return all;
	}
	
	// takes a string and returns a string that is purely numerical, with no decimals either
	private static String removeNonNumerical(String str){
		int periodIndex = str.indexOf(".");
		if (periodIndex != -1)
		{
		    str = str.substring(0, periodIndex);
		}
		str = str.replaceAll("\\D+","");
		if (str.equalsIgnoreCase(""))
			str = "-1";
		return str;
	}
	
	public static void main(String[] args) {
		GenTrees.generate();
		//test
	}
	
}
