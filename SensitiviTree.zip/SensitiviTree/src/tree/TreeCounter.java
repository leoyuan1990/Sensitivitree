package tree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dataSensitiviTree.UserValues;

/*
 * Returns a hashmap of the count of each species of tree within a certain
 * radius around the coordinate values set by the user
 */
public class TreeCounter {
	
	private static double userX = UserValues.getX();
	private static double userY = UserValues.getY();
	private static HashMap<String, Integer> speciesCount = new HashMap<String, Integer>();
	
	public static HashMap<String, Integer> count(Tree[] trees, double radius) {
		
		// check each tree in the tree array
		for (Tree tree : trees) {
			// first check if the tree is within our desired radius
			if (tree.distTo() <= radius) {
				// if the species is already in our HashMap, increment the count by one
				if (speciesCount.containsKey(tree.getSpecies())){
					speciesCount.put(tree.getSpecies(),(int) speciesCount.get(tree.getSpecies()) + 1);
				}
				// then this must be a new species, add a new entry of this species and set its value to one
				else {
					speciesCount.put(tree.getSpecies(), 1);
				}
			}
		}
		return speciesCount;
	}
	
public static List<Tree> treesInRadius(Tree[] trees, double radius) {
		List<Tree> treesInRadius = new ArrayList<Tree>();
		// check each tree in the tree array
		for (Tree tree : trees) {
			// first check if the tree is within our desired radius
			if (tree.distTo() <= radius) {
				treesInRadius.add(tree);
			}
		}
		return treesInRadius;
	}
}
