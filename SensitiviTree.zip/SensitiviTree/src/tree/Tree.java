package tree;

import dataSensitiviTree.UserValues;

/*
 * class for a tree object representing a single tree
 */
public class Tree implements Comparable<Tree> {

	private int addnum;
	private int addstr;
	private String location;
	private String species;
	private int dbh;
	private String street;
	private double x1;
	private double y1;
	private String fullAddressName;

	public Tree(int addnum, int addstr, String location, String species, int dbh, String street) {
		this.addnum = addnum;
		this.addstr = addstr;
		this.location = location;
		this.species = species;
		this.dbh = dbh;
		this.street = street;
	}

	public int getAddNum() {
		return this.addnum;
	}

	public int getAddStr() {
		return this.addstr;
	}

	public String getLocation() {
		return this.location;
	}

	public String getSpecies() {
		return this.species;
	}

	public int getdbh() {
		return this.addstr;
	}

	public String getStreet() {
		return this.street;
	}

	public double getX() {
		return x1;
	}

	public double getY() {
		return y1;
	}

	public void setX(double x) {
		x1 = x;
	}

	public void setY(double y) {
		y1 = y;
	}

	public String getAddressFullName() {
		return (this.getAddNum() + " " + this.getStreet());
	}

	// public double distTo(Tree other) {
	// double x2 = other.getX();
	// double y2 = other.getY();
	// return Math.sqrt(Math.pow(x2 - x, 2) + Math.pow(y2 - y, 2));
	// }

	public double distTo() {
		//System.out.println("User x and y: " + UserValues.getX() + ", " + UserValues.getY());
		double dist = Math.sqrt(Math.pow(x1 - UserValues.getX(), 2) + Math.pow(y1 - UserValues.getY(), 2));
		//System.out.println(dist);
		return dist;
	}

	@Override
	// THIS IS IMPORTANT
	// This will need to be modified to compare two trees and determine whichever
	// is closer
	// to UserValues.userX and UserValues.userY
	// TODO
	public int compareTo(Tree other) {
		if (this.distTo() < other.distTo()) {
			return -1;
		} else if (this.distTo() > other.distTo()) {
			return 1;
		} else {
			return 0;
		}
		// now check which tree is closer to "coords" and return either 1, 0, or
		// -1
	}

}
