package pollenCalculation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TreeAllergenLevel {
	
	/*
	 * This class is used to figure out what pollen severity a SINGLE species of tree has
	 * Used when calculating the pollen ratings of all the nearby.
	 */
	private static HashMap<String, Integer> speciesRating = new HashMap<String, Integer>();
	// based on www.pollenlibrary.com
	// 10 is the worst, most pollen trees and cause the most allergies
	// 1 is the best, least pollen, and least allergy causing tree
	public static void rateSpecies(){
		speciesRating.put("pine",0);
		speciesRating.put("oak",9);
		speciesRating.put("maple",8);
		speciesRating.put("juniper",10);
		speciesRating.put("cypress",10);
		speciesRating.put("willow",9);
		speciesRating.put("ash",9);
		speciesRating.put("birch",7);
		speciesRating.put("yew",0);
		speciesRating.put("alder",6);
		speciesRating.put("starfruit",1);
		speciesRating.put("fir",1);
		speciesRating.put("sapote",2);
		speciesRating.put("pomegranate",2);
		speciesRating.put("apricot",2);
		speciesRating.put("staghorn",2);
		speciesRating.put("spruce",0);
		speciesRating.put("linden",5);
		speciesRating.put("hawthorn",2);
		speciesRating.put("catalpa",2);
		speciesRating.put("magnolia",2);
		speciesRating.put("hazel",5);
		speciesRating.put("olive",2);
		speciesRating.put("aspen",5);
		speciesRating.put("walnut",9);
		speciesRating.put("larch",0);
		speciesRating.put("kentucky",2);
		speciesRating.put("locust",2);
		speciesRating.put("elm",5);
		speciesRating.put("goldenchain",0);
		speciesRating.put("sycamore",2);
		speciesRating.put("cherry",2);
		speciesRating.put("corktree",0);
		speciesRating.put("beech",2);
		speciesRating.put("basswood",10);
		speciesRating.put("whitebeam",0);
		speciesRating.put("ginkgo",5);
		speciesRating.put("hemlock",0);
		speciesRating.put("pear",2);
		speciesRating.put("redbud",2);
		speciesRating.put("poplar",5);
		speciesRating.put("mulberry",10);
		speciesRating.put("cottonwood",10);
		speciesRating.put("see notes", 0);
		speciesRating.put("juniper",2);
		speciesRating.put("apple",1);
		speciesRating.put("tulip",2);
		speciesRating.put("cedar",7);
		speciesRating.put("hackberry",5);
		speciesRating.put("buckeye",0);
		speciesRating.put("dogwood", 2);
		speciesRating.put("lilac",0);
		speciesRating.put("serviceberry",2);
		speciesRating.put("hickory",10);
		speciesRating.put("katsura",0);
		speciesRating.put("crabapple",2);
		speciesRating.put("horse",0);
		speciesRating.put("butternut",9);
		speciesRating.put("nannyberry",0);
	}
	
	public static int calculateAllergen(String species){
		rateSpecies();
		species = species.toLowerCase();
		for (Map.Entry<String, Integer> entry : speciesRating.entrySet()) {
			if (species.contains(entry.getKey().toLowerCase()))
				return entry.getValue();
		}     
	    return 0;
	}
	
}
