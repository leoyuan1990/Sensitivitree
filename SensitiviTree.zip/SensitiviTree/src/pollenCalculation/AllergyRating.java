package pollenCalculation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tree.Tree;
import tree.TreeCounter;

public class AllergyRating {
	
	public static double calculateRating(Tree[] trees, double radius) {
		
		List<Tree> nearbyTrees = TreeCounter.treesInRadius(trees, radius);
		double sensRating = 0;
		double treeAllergenRating = 0;
		double distMultiplier;
		
		for (Tree tree : nearbyTrees){
			treeAllergenRating = TreeAllergenLevel.calculateAllergen(tree.getSpecies());
			distMultiplier = getDistMultipler(tree.distTo());
			sensRating = sensRating + (treeAllergenRating * distMultiplier); 
		}
		return sensRating;
		
	}
	
public static List<Tree> nearbyAllergenicTrees(Tree[] trees, double radius) {
		
		//SensitiviTree rating is 10 at worse, so if you have 
		List<Tree> nearbyTrees = TreeCounter.treesInRadius(trees, radius);
		List<Tree> nearbyAllergenicTrees = new ArrayList<Tree>();
		double treeAllergenRating = 0;
		for (Tree tree : nearbyTrees){
			treeAllergenRating = TreeAllergenLevel.calculateAllergen(tree.getSpecies());
			if (treeAllergenRating >= 9) nearbyAllergenicTrees.add(tree);
		}
		return nearbyAllergenicTrees;
		
	}
	
	public static double getDistMultipler(double distance) {
		if (distance < 25) {
			return 1;
		}
		else if (distance < 100){
			return 0.75;
		}
		else if (distance < 200){
			return 0.25;
		}
		else {
			return 0;
		}
	}

}
