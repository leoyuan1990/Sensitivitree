package address;

import java.util.ArrayList;
import java.util.List;

import algorithms.RedBlackBST;
import dataSensitiviTree.UserValues;

public class OptimizeCoordinates {
	
	public static Coordinate[] optimizeCoordinate(Coordinate[] coordinates) {
		
		RedBlackBST addressesBST = AddressFinder.getBST();
		Address userTo = (Address) addressesBST.get(UserValues.getFindStreet());
		Address userFrom = (Address) addressesBST.get(UserValues.getInputStreet());
		UserValues.setUserAddress(userFrom);
		
		double addressToFromDistance = userTo.distanceBetween(userFrom);
		
		Coordinate origin = null;
		if (UserValues.getUserAddress() == null) {
			System.out.println("Error, the user hasn't entered an address yet");
		}
		else {
			for (Coordinate c : coordinates) {
				if (c.getCoordID() == UserValues.getUserAddress().getCoordID()) {
					origin = c;
				}
			}	
		}
		
		int inRange = 0;
		List<Coordinate> inRangeCoords = new ArrayList<Coordinate>();
		for (Coordinate c : coordinates) {
			if (origin.distanceBetween(c) < addressToFromDistance*1.25) { //this was 4
				inRange++;
				inRangeCoords.add(c);
			}
		}
		
		Coordinate[] optimizedCoordinates = new Coordinate[inRangeCoords.size()];
		for (int i = 0; i < inRangeCoords.size(); i++){
			optimizedCoordinates[i] = inRangeCoords.get(i);
			optimizedCoordinates[i].setOptCoordID(i);
		}
		//System.out.println(optimizedCoordinates.length);
		return optimizedCoordinates;
	}

}
