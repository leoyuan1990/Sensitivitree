package address;

import algorithms.RedBlackBST;

public class AddressFinder {
	
	private static RedBlackBST addressBST;
	
	public static void buildAddressBST(Address[] addresses){
		
		addressBST = new RedBlackBST();
		for (Address address : addresses) {
			addressBST.put(address.toString(), address);
		}
	}
	
	public static RedBlackBST getBST(){
		return addressBST;
	}
}
