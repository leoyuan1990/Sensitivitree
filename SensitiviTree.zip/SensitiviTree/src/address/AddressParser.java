package address;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import com.opencsv.CSVReader;

/*
 * this class is used to read address-points.csv
 * then return an array of address objects
 */
public final class AddressParser {

	private static List<String[]> addressesList;
	private static String[] csvHeaders;
	private static final String datafolder = "data";

	/*
	 * this is a utility class, (like util.math) so the constructor should not
	 * be initialized. It is still required however.
	 */
	private AddressParser() {
	}

	/*
	 * generates an array of addresses, containing the address number, address
	 * name, and address full name (number + street)
	 */
	public static Address[] genAddresses() throws IOException {
		
		File addressPoints = new File(datafolder + "\\address-points.csv");
		CSVReader reader = new CSVReader(new FileReader(addressPoints));
		// this stores the headers (column titles)
		// by reading only the first line
		csvHeaders = reader.readNext(); //read one line
		// now we start reading from the second line
		// where the actual CSV values begin
		addressesList = reader.readAll(); //read the rest
		reader.close();

		// this is the return variable, an Address array
		Address[] addresses = new Address[addressesList.size()];

		int i = 0;
		for (String[] address : addressesList) {
			// this constructs an address object with 5 arguments
			addresses[i++] = new Address
					((Integer.parseInt(address[headerIndex("ADDRNUM")])), // arg1 (int)
					address[headerIndex("FULLNAME")], // arg2 (String)
					address[headerIndex("FULLADDR")], // arg3 (String)
					Double.parseDouble(address[headerIndex("POINT_X")]), // arg4 (double)
					Double.parseDouble(address[headerIndex("POINT_Y")])); // arg5 (double)
			
		}
		return addresses;
	}

	/*
	 * helper method to convert CSV headers to their corresponding column value
	 * this method lets you enter a desired header (not case sensitive) and it
	 * will return the index value with the value associated with the header
	 */
	private static int headerIndex(String header) {
		for (int i = 0; i < csvHeaders.length; i++)
			if (csvHeaders[i].equalsIgnoreCase(header))
				return i;
		return -1;
	}

}
