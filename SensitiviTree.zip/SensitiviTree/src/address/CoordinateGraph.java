package address;

import java.io.FileWriter;
import java.io.IOException;

import algorithms.DijkstraSP;
import algorithms.DirectedEdge;
import algorithms.EdgeWeightedDigraph;
import algorithms.Graph;
import algorithms.Quick;
import algorithms.RedBlackBST;
import algorithms.ST;

public class CoordinateGraph {

	public static EdgeWeightedDigraph buildCoordinateGraph(Coordinate[] coordinates) throws IOException {
		
		EdgeWeightedDigraph graph = new EdgeWeightedDigraph(coordinates.length);
		
		int counter = 0;
		ST<Integer,Coordinate> stCoordIDs = Coordinate.findOptID(coordinates);
		for (Coordinate start : coordinates) {
			counter++;
			if (counter == coordinates.length) {
				System.out.println("Halfway through adding edges to the graph...");
			}
			for (Integer i : start.getNearbyCoordIDs()) {
				
				DirectedEdge de = new DirectedEdge(start.getOptCoordID(), stCoordIDs.get(i).getOptCoordID(), start.distanceBetween(stCoordIDs.get(i)));
				graph.addEdge(de);
			}
		}
		System.out.println("Graph Completed...");
		return graph;
		
//		System.out.println(graph.E());
		
//		for (Coordinate c : coordinates) {
//			if (c.getNearbyCoordIDs().size() > 1){
//				System.out.println(c.getCoordID() + " and " + c.getNearbyCoordIDs());
//			}
//		}
//		
//		System.out.println("Creating DijkstraSP...");
//		DijkstraSP sp = new DijkstraSP(graph, 170841);
//		
//		System.out.println("Starting at: " + Coordinate.findCoordinateFromID(coordinates, 170841));
//		for (DirectedEdge e : sp.pathTo(72728)){
//			System.out.println("Visit: " + Coordinate.findCoordinateFromID(coordinates, e.to()));
//		}
	}
}
