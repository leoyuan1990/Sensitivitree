package address;

import java.io.IOException;

import algorithms.DijkstraSP;
import algorithms.DirectedEdge;
import algorithms.EdgeWeightedDigraph;
import algorithms.RedBlackBST;

public class FindShortestPath {
	
	/*
	 * Constructs a graph and finds the shortest path
	 */
	public static String findPath(Address[] addresses, Coordinate [] coordinates, String a1, String a2) throws IOException {
		
		RedBlackBST addressesBST = AddressFinder.getBST();
		Address addressFrom = (Address) addressesBST.get(a1);
		Address addressTo = (Address) addressesBST.get(a2);
		
		Coordinate cFrom = null;
		Coordinate cTo = null;
		
		
		for (Coordinate c : coordinates) {
			//System.out.println(c.getCoordID() + " and " + addressFrom.getCoordID());
			if (c.getCoordID() == addressFrom.getCoordID()){
				cFrom = c;
			}
			if (c.getCoordID() == addressTo.getCoordID()) {
				cTo = c;
			}
		}
		String result = "";
		EdgeWeightedDigraph graph = CoordinateGraph.buildCoordinateGraph(coordinates);
		DijkstraSP shortestPath = new DijkstraSP(graph, cFrom.getOptCoordID());
		result += "Starting at " + Address.addressFinderFromCoordId(addresses, cFrom.getCoordID()) + "\n";
		for (DirectedEdge e : shortestPath.pathTo(cTo.getOptCoordID())){
			result += "Visit: " + Address.addressFinderFromCoordId(addresses, Coordinate.findCoordinateFromOPID(coordinates, e.to()).getCoordID()) + "\n";
		}
		
		return result;
		
	}

}
