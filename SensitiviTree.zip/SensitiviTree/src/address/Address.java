package address;

import java.util.ArrayList;
import java.util.List;

/*
 * This class is represents an address object, a single line in the address-points.csv
 */
public class Address implements Comparable<Address> {
	private static int globalIDCounter = 0;
	private int addNum;
	private String addName;
	private String addFullName;
	private double pointX;
	private double pointY;
	private Integer id;
	private int coordID;
	private List<Integer> nearAddresses = new ArrayList<Integer>();
	private Coordinate c;

	public Address(int addNum, String addName, String addFullName, double pointX, double pointY) {
		this.addNum = addNum;
		this.addName = addName;
		this.addFullName = addFullName;
		this.pointX = pointX;
		this.pointY = pointY;
		id = globalIDCounter++;
		this.c = new Coordinate(pointX,pointY);
	}
	
	public int getAddNum() {
		return addNum;
	}

	public String getAddName() {
		return addName;
	}

	public String getAddFullName() {
		return addFullName;
	}
	
	public Coordinate getCoordinate(){
		return this.c;
	}
	
	public int getCoordID() {
		return coordID;
	}
	
	public void setCoordID(int i) {
		coordID = i;
	}

	public double getPointX() {
		return pointX;
	}

	public double getPointY() {
		return pointY;
	}
	
	public void addNearbyAddress(int otherID) {
		nearAddresses.add(otherID);
	}
	public Integer getID(){
		return id;
	}
	public List<Integer> returnNearbyIds(){
		return nearAddresses;
	}

	/*
	 * Compares another address and returns which is closer, based on a relative
	 * x and y point 0 is same distance -1 means this address is closer 1 means
	 * that address is closer
	 */
	public int compareDistance(Address that, double x, double y) {
		double thisDistance = Math.sqrt(Math.pow((x - this.getPointX()), 2) + Math.pow((y - this.getPointY()), 2));
		double thatDistance = Math.sqrt(Math.pow((x - that.getPointX()), 2) + Math.pow((y - that.getPointY()), 2));

		if (thisDistance < thatDistance)
			return -1;
		if (thisDistance > thatDistance)
			return 1;
		return 0;
	}
	
	/*
	 * Calculate the distance between two addreses
	 */
	public double distanceBetween(Address that) {
		double dist = Math.sqrt(Math.pow((this.getPointX() - that.getPointX()), 2) + Math.pow((this.getPointY() - that.getPointY()), 2));
		return dist;
	}

	@Override
	/*
	 * compares the address FULL names and returns an integer
	 * -1 if this address occurs before that address
	 * 0 if this address is the same as that address
	 * 1 if this address occurs after that address
	 */
	public int compareTo(Address that) {
		if (this.pointX > that.getPointX())
			return 1;
		else if (this.pointX < that.pointX)
			return -1;
		else 
			return 0;
	}
	
	public String toString() {
		return addFullName;
	}
	
	public static Address addressFinder(Address[] addresses, int id){
		for (Address a : addresses) {
			if (a.getID() == id) {
				return a;
			}
		}
		return null;
	}
	
	public static Address addressFinderFromCoordId(Address[] addresses, int id){
		for (Address a : addresses) {
			if (a.getCoordID() == id) {
				return a;
			}
		}
		return null;
	}
}
