package address;

import java.util.ArrayList;
import java.util.List;

import algorithms.ST;

public class Coordinate implements Comparable<Coordinate>  {
	
	private double x;
	private double y;
	private List<Integer> addressIds = new ArrayList();
	private List<Integer> nearbyCoordIDs = new ArrayList();
	private int coordID;
	private int optimizedID;
	
	public Coordinate(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public List<Integer> getAddressIds() {
		return addressIds;
	}
	
	@Override
	public String toString() {
		return "Coordinate [x=" + x + ", y=" + y + "]";
	}

	public void addAddressId(Integer i) {
		addressIds.add(i);
	}
	
	public void addCoordId(Integer i) {
		nearbyCoordIDs.add(i);
	}
	
	public List<Integer> getNearbyCoordIDs() {
		return nearbyCoordIDs;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public double getX() {
		return this.x;
	}
	
	public int getCoordID() {
		return coordID;
	}
	
	public void setCoordID(int i) {
		coordID = i;
	}
	
	public int getOptCoordID() {
		return optimizedID;
	}
	
	public void setOptCoordID(int i) {
		optimizedID = i;
	}
	
	public double getY() {
		return this.y;
	}
	
	public double distanceBetween(Coordinate that) {
		double dist = Math.sqrt(Math.pow((this.getX() - that.getX()), 2) + Math.pow((this.getY() - that.getY()), 2));
		return dist;
	}

	@Override
	public int compareTo(Coordinate c) {
		if (this.x > c.getX())
			return 1;
		else if (this.x < c.getX())
			return -1;
		else 
			return 0;
	}

	@Override
	public boolean equals(Object obj) {
		Coordinate c = (Coordinate) obj;
		if ((this.x == c.getX()) && (this.y == c.getY())) {
			return true;
		}
		return false;
	}
	
	public static Coordinate findCoordinateFromID(Coordinate[] coordinates, int id){
		for (Coordinate c : coordinates) {
			if (c.getCoordID() == id) {
				return c;
			}
		}
		return null;
	}
	
	public static Coordinate findCoordinateFromOPID(Coordinate[] coordinates, int id){
		for (Coordinate c : coordinates) {
			if (c.getOptCoordID() == id) {
				return c;
			}
		}
		return null;
	}
	
	public static ST findOptID(Coordinate [] coordinates) {
		ST<Integer,Coordinate> stCoordID = new ST<Integer,Coordinate>();
		
		for (Coordinate c : coordinates) {
			stCoordID.put(c.getCoordID(), c);
		}
		return stCoordID;
	}
	
	public static ST findSTID(Coordinate [] coordinates) {
		ST<Integer,Coordinate> stCoordID = new ST<Integer,Coordinate>();
		for (Coordinate c : coordinates) {
			stCoordID.put(c.getCoordID(), c);
		}
		return stCoordID;
	}
}
