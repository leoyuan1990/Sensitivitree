package address;

import algorithms.Quick;

public class CoordinatesNearby {
	
	private static final double MAX_ADJ_DISTANCE = 100;
	
	/*
	 * determines what coordinates are within a MAX_ADJ_DISTANCE
	 * and if a coordinate is nearby, then update the list of nearby coord IDs
	 */
	public static void findNearbyCoordinate(Coordinate[] coordArray) {
		
		Quick.sort(coordArray);
		
		int left;
		int right;
		int counter = 0;
		// Loop through each address to find adjacencies
		System.out.println("Finding adjacencies...");
		for (int i = 0; i < coordArray.length; i++) {
			//System.out.println(i);
			
			left = i - 1;
			right = i + 1;
			
			if (left >= 0) {
			while (compareX(coordArray[i], coordArray[left])) {
				if (coordArray[i].distanceBetween(coordArray[left]) <= MAX_ADJ_DISTANCE && coordArray[i].distanceBetween(coordArray[left]) != 0) {
					coordArray[i].addCoordId(coordArray[left].getCoordID());
				}
				--left;
				if (left < 0)
					break;
			}
			}
			if (right < coordArray.length) {
			while (compareX(coordArray[i], coordArray[right])) {
				if (coordArray[i].distanceBetween(coordArray[right]) <= MAX_ADJ_DISTANCE && coordArray[i].distanceBetween(coordArray[right]) != 0) {
					coordArray[i].addCoordId(coordArray[right].getCoordID());
				}
				++right;
				if (right >= coordArray.length)
					break;
			}
			}
		}
	}
	
	private static boolean compareX(Coordinate c1, Coordinate c2) {
		if ((Math.abs(c1.getX() - c2.getX()) <= MAX_ADJ_DISTANCE))
			return true;
		return false;
	}

}
