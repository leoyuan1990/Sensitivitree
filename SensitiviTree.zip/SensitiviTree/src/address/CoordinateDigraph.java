package address;

import algorithms.Digraph;

public class CoordinateDigraph {
	
	public static Digraph buildDigraph(Coordinate[] coordinates){
		
		Digraph graph = new Digraph(coordinates.length);
		
		for (Coordinate c : coordinates){
			for (Integer i : c.getNearbyCoordIDs()) {
				graph.addEdge(c.getCoordID(), i);
			}
		}
		return graph;
		
	}
	

}
