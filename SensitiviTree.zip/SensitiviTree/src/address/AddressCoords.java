package address;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import algorithms.Quick;
import algorithms.RedBlackBST;
import algorithms.ST;

/*
 * This class is used to store all unique coordinates
 */
public class AddressCoords {
	
	private static ST<Coordinate,Coordinate> STCoords = new ST<Coordinate,Coordinate>();
	
	public static Coordinate[] buildCoords(Address[] addresses) throws IOException {
		
		int coordIds = 0;
		System.out.println("Assigning addresses to coordinates...");
		for (Address a : addresses) {
			if (!STCoords.contains(a.getCoordinate())) {
				Coordinate currentCoord = a.getCoordinate();
				currentCoord.setCoordID(coordIds);
				STCoords.put(a.getCoordinate(), currentCoord);
				STCoords.get(a.getCoordinate()).addAddressId(a.getID());
				a.setCoordID(coordIds);
				coordIds++;
			}
			else {
				STCoords.get(a.getCoordinate()).addAddressId(a.getID());
				a.setCoordID(coordIds);
			}
		}
		int i = 0;
		Coordinate [] coordArray = new Coordinate [STCoords.size()];
		for (Coordinate c : STCoords.keys()) {
			coordArray[i++] = STCoords.get(c);
		}
		
		return coordArray;
	}
}
